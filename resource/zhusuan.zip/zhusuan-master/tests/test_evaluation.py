#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division

import tensorflow as tf

from zhusuan.evaluation import *


class TestIsLogLikelihood(tf.test.TestCase):
    def test_is_loglikelihood(self):
        # TODO: is_loglikelihood test
        pass
