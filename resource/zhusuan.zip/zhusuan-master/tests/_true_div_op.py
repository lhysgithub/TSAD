#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import division


def true_div(x, y):
    return x / y
