zhusuan\.evaluation 
==========================

.. automodule:: zhusuan.evaluation
    :members:
    :undoc-members:
    :show-inheritance:
