zhusuan\.hmc 
===================

.. automodule:: zhusuan.hmc
    :members:
    :undoc-members:
    :show-inheritance:
