zhusuan\.legacy 
======================

.. automodule:: zhusuan.legacy
    :members:
    :undoc-members:
    :show-inheritance:

Special
------------

.. automodule:: zhusuan.legacy.distributions.special
    :members:
    :undoc-members:
    :show-inheritance:

Stochastic
-----------------

.. automodule:: zhusuan.legacy.framework.stochastic
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members: