zhusuan\.framework 
======================

.. automodule:: zhusuan.framework
    :members:
    :undoc-members:
    :show-inheritance:

BayesianNet
------------

.. automodule:: zhusuan.framework.bn
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:

MetaBayesianNet
-----------------

.. automodule:: zhusuan.framework.meta_bn
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:

Utils
-----

.. automodule:: zhusuan.framework.utils
    :members:
    :undoc-members:
    :show-inheritance:
