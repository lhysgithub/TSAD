from .dense_ import *

__all__ = [
    'dense',
]
