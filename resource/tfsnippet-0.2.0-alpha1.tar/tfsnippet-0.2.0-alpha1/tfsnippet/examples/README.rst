Examples for TFSnippet
======================

If you want to run any example script, you must first install the dependencies
from `requirements-dev.txt`.
