tfsnippet\.ops
==============

.. automodapi:: tfsnippet.ops
