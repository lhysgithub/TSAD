API Docs
========

.. toctree::
   :maxdepth: 1

   tfsnippet
   tfsnippet.dataflows
   tfsnippet.datasets
   tfsnippet.layers
   tfsnippet.ops
   tfsnippet.preprocessing
   tfsnippet.utils
